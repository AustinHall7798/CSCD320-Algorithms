
public class BinaryTree {
	private Node root;

	private static class Node {
		Node left;
		Node right;
		Object data;

		public Node(Object newData) {
			this.left = null;
			this.right = null;
			this.data = newData;
		}
	}
	
	public BinaryTree() {
		root = null;
	}
	
	static BinaryTree buildTree(Object inOrderSequence[], Object postOrderSequence[]) {
		BinaryTree mytree = new BinaryTree();
		mytree.root = buildTree(inOrderSequence, postOrderSequence, 0, postOrderSequence.length - 1, 0, postOrderSequence.length - 1);
		return mytree;
	}
	
	private static Node buildTree(Object[] in, Object[] post, int inStart, int inEnd, int postStart, int postEnd) {
		if (inStart > inEnd) {
			return null;
		}

		Node root = new Node(post[postEnd]);

		if (inStart == inEnd) {
			return root;
		}
		
		int rootIndex = getRootIndex(in, inStart, inEnd, root.data);
		
		root.left = buildTree(in, post, inStart, rootIndex - 1, postStart, postStart + rootIndex - (inStart + 1));
		
		root.right = buildTree(in, post, rootIndex + 1, inEnd, postStart + rootIndex - inStart, postEnd - 1);
		
		return root;
	}

	private static int getRootIndex(Object[] inOrder, int start, int end, Object data) {
		for (int i = start; i <= end; i++) {
			if (inOrder[i].equals(data)) {
				return i;
			}
		}
		return -1;
	}
	
	public void printPostOrder() {
		System.out.print("Post-order output: ");
		printPostOrder(root);
		System.out.println();
	}

	private void printPostOrder(Node node) {
		if (node == null)
			return;

		printPostOrder(node.left);

		printPostOrder(node.right);

		System.out.print(node.data + ", ");
	}

	public void printInOrder() {
		System.out.print("In-order output: ");
		printInOrder(root);
		System.out.println();
	}

	private void printInOrder(Node node) {
		if (node == null)
			return;

		printInOrder(node.left);

		System.out.print(node.data + ", ");

		printInOrder(node.right);
	}
}
