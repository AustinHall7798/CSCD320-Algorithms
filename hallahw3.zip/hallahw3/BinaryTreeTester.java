
public class BinaryTreeTester {

	public static void main(String[] args) {
		Object inOrderSequence[]= {9, 5, 1, 7, 2, 12, 8, 4, 3, 11 };
		Object postOrderSequence[]={9, 1, 2, 12, 7, 5, 3, 11, 4, 8};
		
		BinaryTree mytree = BinaryTree.buildTree(inOrderSequence, postOrderSequence);
		
		System.out.println("In-order input: " + printArray(inOrderSequence));
		System.out.println("Post-order input: " + printArray(postOrderSequence));
		
		System.out.println();
		
		mytree.printInOrder();
		mytree.printPostOrder();
	}
	
	public static String printArray(Object arr[]) {
		String output = "";
		for(int i = 0; i < arr.length; i++) {
			output += arr[i] + ", ";
		}
		return output;
	}

}
