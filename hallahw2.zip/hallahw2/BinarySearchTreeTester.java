
public class BinarySearchTreeTester {

	public static void main(String[] args) {
		BinarySearchTree myBST = new BinarySearchTree();
		myBST.insert(new Integer(8));
		myBST.insert(new Integer(3));
		myBST.insert(new Integer(1));
		myBST.insert(new Integer(6));
		myBST.insert(new Integer(4));
		myBST.insert(new Integer(7));
		myBST.insert(new Integer(10));
		myBST.insert(new Integer(14));
		myBST.insert(new Integer(13));
		
		myBST.printInOrder();
		System.out.println();
		myBST.printPostOrder();
		
		System.out.println();
		
		myBST.delete(new Integer(8));
		myBST.printInOrder();
		System.out.println();
		myBST.printPostOrder();
		
		System.out.println();
		
		myBST.delete(new Integer(10));
		myBST.printInOrder();
		System.out.println();
		myBST.printPostOrder();
	}
}

// I am able to get the post order traversal results because first, the root node
// of the myBST object is passed in. This root node is now 7 because of the
// prvious deletion. The program will then go left until it encounters a null left
// node. So it starts at 7, goes left to 3, goes left to 1, and then stops because
// there is nothing to the left of 1. It returns to the previous node which is 
// 1 because it was at the null 1.left node. Now it will go to the next part of
// the method since it's been returned which is go right. It goes right to the
// null node. Since this is null, it returns back to 1. The next step of the
// method is to print the node, so it prints 1. Then it exits this recurssive 
// call to return to the previous (which was 3.left). Since it's already gone
// left, 3 now goes right. It is at 6. 6 is able to go left so now its at 4.
// It goes left to the null node, then returns back to 4 since it was null. 4
// attempts to go right, it does and the node is null so it returns to 4. Since
// 4 has attempted left and right, it will print itself. The console output is now
// 1 4. Now that its printed, the current node returns to the previous call which was
// 6. 6 alredy went left to 4, so now it goes right. This is a null node so it returns
// back to 6. 6 has gone left and right so now it prints. The console output
// is now 1 4 6. 6 has gone left and right, so now it returns to the previous call, 
// which was 3. 3 has gone left and right, so now it prints. Console output is now
// 1 4 6 3. Since 3 has printed, it returns to its previous call, 7. 7 already went
// left, so now it goes right, to 14. 14 goes left which is 13. 13 goes left
// and the node is null so it returns back to the previous call which is 13. 13 goes
// right, which is a null node and returns to 13. 13 went left and right so now
// it prints itself. Console output is 1 4 6 3 13. Since 13 printed, it goes back to its
// previous call, which is 14. 14 already went left, so now it goes right. 14.right
// is a null node, so it returns. 14 has gone left and right so it prints itself.
// The output is now 1 4 6 3 13 14. 14 printed itself so now it returns to its caller
// which was 7. 7 has gone left already, and just finished going right, so now it 
// prints itself. The console output is 1 4 6 3 13 14 7. 7 has printed itself, so
// now its time to return. Since 7 was the original call, this method is now complete.