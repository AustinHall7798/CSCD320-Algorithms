
public class BinarySearchTree {

	private Node root;

	private class Node {
		Node left;
		Node right;
		Comparable data;

		public Node(Comparable newData) {
			this.left = null;
			this.right = null;
			this.data = newData;
		}
	}

	public BinarySearchTree() {
		root = null;
	}

	public void insert(Comparable newData) {
		root = insert(root, newData);
	}

	private Node insert(Node node, Comparable newData) {
		if (node == null) {
			node = new Node(newData);
		} else if (node.data.compareTo(newData) >= 0) {
			node.left = insert(node.left, newData);
		} else {
			node.right = insert(node.right, newData);
		}
		return node;
	}

	public void printPostOrder() {
		printPostOrder(root);
	}

	public void printPostOrder(Node node) {
		if (node == null)
			return;

		printPostOrder(node.left);

		printPostOrder(node.right);

		System.out.print(node.data + " ");
	}

	public void printInOrder() {
		printInOrder(root);
	}

	public void printInOrder(Node node) {
		if (node == null)
			return;

		printInOrder(node.left);

		System.out.print(node.data + " ");

		printInOrder(node.right);
	}

	public boolean delete(Comparable toRemove) {
		boolean[] removed = new boolean[1];
		removed[0] = false;
		this.root = delete(root, toRemove, removed);
		return removed[0];
	}

	private Node delete(Node rootNode, Comparable entry, boolean[] removed) {
		if (rootNode != null) {
			Comparable rootData = rootNode.data;

			if (entry.equals(rootData)) {
				removed[0] = true;
				rootNode = removeEntry(rootNode, entry);
			} else if (entry.compareTo(rootData) < 0) {
				Node subtreeRoot = delete(rootNode.left, entry, removed);
				rootNode.left = subtreeRoot;
			} else {
				rootNode.right = delete(rootNode.right, entry, removed);
			}
		}

		return rootNode;
	}

	private Node removeEntry(Node node, Comparable toRemove) {
		if (node.left != null && node.right != null) {
			Node largestNode = findLargest(node.left);

			node.data = largestNode.data;

			node.left = removeLargest(node.left);
		} else if (node.right != null) {
			node = node.right;
		} else {
			node = node.left;
		}
		return node;
	}

	private Node findLargest(Node rootNode) {
		if (rootNode.right != null) {
			rootNode = findLargest(rootNode.right);
		}
		return rootNode;
	}

	private Node removeLargest(Node rootNode) {
		if (rootNode.right != null) {
			Node cur = removeLargest(rootNode.right);
			rootNode.right = cur;
		} else
			rootNode = rootNode.left;

		return rootNode;
	}

}
