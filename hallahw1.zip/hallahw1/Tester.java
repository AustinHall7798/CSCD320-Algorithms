
public class Tester {

	public static void main(String[] args) {
		int[] A = new int[] { 1, 3, 5, 7, 9, 14, 16, 19 };
		System.out.println("Using an input array A = " + toString(A) + ",");
		printResults(A, 8);
		printResults(A, 19);
		printResults(A, 20);
		printResults(A, 6);
		printResults(A, -1);
	}

	public static int quickSearch(int array[], int value) {
		if (value > array[array.length - 1]) {
			return -1;
		}
		int l = 0, r = array.length - 1, m = 0;
		while (l <= r) {
			m = l + (r - l) / 2;
			if (array[m] == value)
				return m;

			if (array[m] < value)
				l = m + 1;

			else
				r = m - 1;
		}

		return l;
	}
	
	public static String toString(int[] arr) {
		String finalArray = "";
		finalArray += "[";
		for(int i = 0; i < arr.length; i++) {
			finalArray += arr[i];
			if(i + 1 != arr.length) {
				finalArray += ", ";
			}
		}
		finalArray += "]";
		return finalArray;
	}
	
	public static void printResults(int[] arr, int value) {
		int index = quickSearch(arr, value);
		if(index >= 0 && index < arr.length) {
			System.out.println("performing quickSearch(A, " + value + "), it return " +
					index + ", the index of number " + arr[index] + ".");
		} else {
			System.out.println("performing quickSearch(A, " + value + "), it return " +
					index + ", indicating there is no such value that is bigger than or equal to " + value + " in array A.");
		}
	}
}
